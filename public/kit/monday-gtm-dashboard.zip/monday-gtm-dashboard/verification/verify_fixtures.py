"""Fixture-integrity gate: every number the class publishes, checked against the
shipped files.

Run it from anywhere:

    python3 kit/monday-gtm-dashboard/verification/verify_fixtures.py

It asserts the answer key in delivery/deal-set-ground-truth.md and the per-job
numbers printed in data/kit/jobs.md against deals-10k.csv and sample-200.csv,
plus the single-seller shape (Pavilion Software) and the 114 preserved
buyer-equals-seller rows the dashboard's health strip flags. Exit code 0 means
every number matched; any drift prints MISMATCH and exits 1.

Added 2026-08-20 after a survey respondent caught the data shape contradicting
the class narrative. The pre-class checklist runs this before every teach.
"""
import csv
import os
import sys
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
FULL = os.path.join(HERE, "..", "deals-10k.csv")
SAMPLE = os.path.join(HERE, "..", "..", "..", "data", "kit", "sample-200.csv")

SELLER = "Pavilion Software"
CUTOFF = date(2026, 5, 5)
OPEN_STAGES = {"Prospecting", "Qualification", "Proposal", "Negotiation"}

failures = []


def parse_date(s):
    if not s:
        return None
    return date(*[int(p) for p in s.split("-")])


def load(path):
    with open(path, newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        # Column names differ in case between the two files; normalise here so
        # both verifications read the same keys.
        keys = [h.lower() for h in header]
        return [dict(zip(keys, row)) for row in reader]


def check(label, actual, expected):
    ok = actual == expected
    print(f"  {label}: {actual} (expected {expected}) {'ok' if ok else 'MISMATCH'}")
    if not ok:
        failures.append(label)


def verify(rows, expectations):
    open_rows = [r for r in rows if r["deal_stage"] in OPEN_STAGES]
    quiet = [
        r for r in open_rows
        if (d := parse_date(r["last_activity_date"])) and d < CUTOFF
    ]
    nodate = [r for r in open_rows if not r["last_activity_date"]]
    lost = [r for r in rows if r["deal_stage"] == "Closed Lost"]
    recon = [
        r for r in lost
        if r["loss_reason_main"] != r["buyer_reported_reason_main"]
    ]
    thin = [r for r in open_rows if int(r["contact_count"] or 0) < 3]
    inverted = [
        r for r in rows
        if r["expected_close_date"]
        and parse_date(r["expected_close_date"]) < parse_date(r["transaction_date"])
    ]
    east_quiet = [r for r in quiet if r["territory"] == "East"]
    east_amt = round(sum(float(r["final_amount"]) for r in east_quiet))
    computed = {
        "rows": len(rows),
        "quiet open deals (job 1)": len(quiet),
        "open deals with no activity date": len(nodate),
        "quiet including no-date": len(quiet) + len(nodate),
        "closed-lost": len(lost),
        "coded vs reported disagree (job 2)": len(recon),
        "thin open deals (job 3)": len(thin),
        "East quiet rows (job 4)": len(east_quiet),
        "East quiet final_amount (job 4)": east_amt,
        "inverted close dates (job 6)": len(inverted),
        "distinct sellers": len({r["seller_company"] for r in rows}),
        "buyer-equals-seller rows": sum(
            1 for r in rows if r["buyer_company"] == r["seller_company"]
        ),
    }
    for label, expected in expectations.items():
        check(label, computed[label], expected)


print("== deals-10k.csv ==")
full_rows = load(FULL)
verify(full_rows, {
    "rows": 10000,
    "quiet open deals (job 1)": 634,
    "open deals with no activity date": 200,
    "quiet including no-date": 834,
    "closed-lost": 2479,
    "coded vs reported disagree (job 2)": 866,
    "thin open deals (job 3)": 1463,
    "East quiet rows (job 4)": 148,
    "East quiet final_amount (job 4)": 19392867,
    "inverted close dates (job 6)": 2248,
    "distinct sellers": 1,
    "buyer-equals-seller rows": 114,
})
check("won", sum(1 for r in full_rows if r["deal_stage"] == "Closed Won"), 2546)
check("open", sum(1 for r in full_rows if r["deal_stage"] in OPEN_STAGES), 4975)
check(
    "every seller is the CRM owner",
    all(r["seller_company"] == SELLER for r in full_rows),
    True,
)

print("== sample-200.csv ==")
sample_rows = load(SAMPLE)
verify(sample_rows, {
    "rows": 200,
    "quiet open deals (job 1)": 15,
    "open deals with no activity date": 4,
    "quiet including no-date": 19,
    "closed-lost": 55,
    "coded vs reported disagree (job 2)": 20,
    "thin open deals (job 3)": 31,
    "East quiet rows (job 4)": 2,
    "East quiet final_amount (job 4)": 126666,
    "inverted close dates (job 6)": 42,
    "distinct sellers": 1,
    "buyer-equals-seller rows": 4,
})
check(
    "Rep-33 closed-lost in sample (job 5)",
    sum(1 for r in sample_rows
        if r["deal_stage"] == "Closed Lost" and r["sales_rep"] == "Rep-33"),
    4,
)

if failures:
    print(f"\n{len(failures)} MISMATCH(ES): the shipped data no longer matches "
          "the published answer key. Fix one or the other before class.")
    sys.exit(1)
print("\nall fixture checks passed")
