const { chromium } = require('playwright');
const fs = require('fs');

const TRUTH = JSON.parse(fs.readFileSync('./truth.json', 'utf8'));
const URL = 'http://127.0.0.1:8899/monday-gtm-dashboard.html?csv=http://127.0.0.1:8899/real-deals.csv';

// The class cloud workspace pins Chromium at this path; on any other machine,
// Playwright's own installed browser is the one that exists.
const EXE = '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';

(async () => {
  const browser = await chromium.launch(fs.existsSync(EXE) ? { executablePath: EXE } : {});
  const page = await browser.newPage({ viewport: { width: 1440, height: 1100 } });

  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });

  await page.goto(URL, { waitUntil: 'networkidle' });
  await page.waitForSelector('#app', { state: 'visible', timeout: 25000 });
  await page.waitForFunction(() => document.querySelector('#p1body .hero') !== null, null, { timeout: 25000 });

  // Pull the dashboard's own computed numbers straight out of its metrics module.
  const got = await page.evaluate(() => {
    const DAY = 86400000;
    const rows = S.rows;
    const wr = M.winRate(rows);
    const openRows = M.open(rows);
    const hi = S.asOf + 30 * DAY;
    const p1 = openRows.filter(d => d.expClose != null && d.expClose >= S.asOf && d.expClose <= hi);
    const aged = d => M.daysUntouched(d, S.asOf);
    const buck = n => openRows.filter(d => { const a = aged(d); return a != null && a >= n; });
    const sum = a => a.reduce((s, d) => s + (d.finalAmount || 0), 0);

    const closed = M.closed(rows);
    const bands = {};
    for (const d of closed) {
      if (d.discountPct == null) continue;
      const b = String(Math.round(d.discountPct));
      bands[b] = bands[b] || { won: 0, lost: 0 };
      if (d.stageClass === 'won') bands[b].won++; else bands[b].lost++;
    }
    for (const k in bands) { bands[k].n = bands[k].won + bands[k].lost; bands[k].rate = bands[k].won / bands[k].n; }

    const SQ = /(no.?decision|no.?competitor|none|internal.?build|status.?quo|do.?nothing|in.?house|budget)/i;
    const blank = v => { const s = String(v == null ? '' : v).trim(); return s === '' || /^(na|n\/a|null|none|unknown|-)$/i.test(s); };
    const named = closed.filter(d => !blank(d.competitor) && !SQ.test(d.competitor));
    const nwr = M.winRate(named);
    const lostAll = closed.filter(M.isLost);
    const sqLost = lostAll.filter(d => blank(d.competitor) || SQ.test(d.competitor));

    const yes = v => /^(y|yes|true|1)$/i.test(String(v || '').trim());
    const nrm = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const pool = rows.filter(d => M.isLost(d) && yes(d.interview) && !blank(d.lossMain) && !blank(d.buyerMain));
    const mis = pool.filter(d => nrm(d.lossMain) !== nrm(d.buyerMain));

    return {
      rows: rows.length, won: wr.won, lost: wr.lost, open: openRows.length,
      winRate: wr.rate,
      revenue: Math.round(M.revenue(rows) * 100) / 100,
      discountGiven: Math.round(M.discountGiven(rows) * 100) / 100,
      realization: M.realization(rows),
      cycleMedian: M.cycleLength(rows),
      p1_count: p1.length, p1_amount: Math.round(sum(p1) * 100) / 100,
      p2_30_count: buck(30).length, p2_30_amount: Math.round(sum(buck(30)) * 100) / 100,
      p2_60_count: buck(60).length, p2_60_amount: Math.round(sum(buck(60)) * 100) / 100,
      p2_90_count: buck(90).length, p2_90_amount: Math.round(sum(buck(90)) * 100) / 100,
      p3_bands: bands,
      p4_namedWinRate: nwr.rate, p4_namedN: nwr.n,
      p4_sqLostShare: sqLost.length / lostAll.length,
      p5_pool: pool.length, p5_mismatch: mis.length,
      p5_mismatchRate: mis.length / pool.length,
      p5_mismatchDollars: Math.round(mis.reduce((s, d) => s + (d.finalAmount || 0), 0) * 100) / 100,
      p5_interviewedLosses: S.health.interviewedLosses,
      h_nullExpClose: S.health.nullExpClose,
      h_nullLastAct: S.health.nullLastAct,
      h_buyerEqSeller: S.health.buyerEqSeller,
      h_segConflict: S.health.segmentConflict,
      h_probIsLookup: S.health.probIsLookup,
      asOf: new Date(S.asOf).toISOString().slice(0, 10),
      unresolved: S.unresolved,
      heroText: document.querySelector('#p1body .hero').textContent.trim(),
    };
  });

  const near = (a, b) => (typeof a === 'number' && typeof b === 'number')
    ? Math.abs(a - b) <= Math.max(0.02, Math.abs(b) * 1e-6)
    : JSON.stringify(a) === JSON.stringify(b);

  const fails = [];
  for (const k of Object.keys(TRUTH)) {
    if (k === 'p3_bands') {
      for (const b of Object.keys(TRUTH.p3_bands)) {
        const t = TRUTH.p3_bands[b], g = got.p3_bands[b];
        if (!g) { fails.push(`p3 band ${b}: missing in dashboard`); continue; }
        for (const f of ['won', 'lost', 'n']) if (t[f] !== g[f]) fails.push(`p3 band ${b}.${f}: truth ${t[f]} vs got ${g[f]}`);
        if (!near(g.rate, t.rate)) fails.push(`p3 band ${b}.rate: truth ${t.rate} vs got ${g.rate}`);
      }
      const extra = Object.keys(got.p3_bands).filter(b => !(b in TRUTH.p3_bands));
      if (extra.length) fails.push('p3 extra bands: ' + extra.join(','));
      continue;
    }
    if (!near(got[k], TRUTH[k])) fails.push(`${k}: truth ${JSON.stringify(TRUTH[k])} vs got ${JSON.stringify(got[k])}`);
  }
  if (got.unresolved.length) fails.push('unresolved columns: ' + got.unresolved.join(','));
  if (got.asOf !== '2026-08-04') fails.push('asOf drift: ' + got.asOf);

  // Interaction smoke tests. Pick whatever territory the file actually has.
  const terr = await page.evaluate(() =>
    [...document.getElementById('fTerritory').options].map(o => o.value).filter(Boolean)[0]);
  if (!terr) fails.push('territory filter has no options');
  await page.selectOption('#fTerritory', terr);
  await page.waitForTimeout(350);
  const filtered = await page.evaluate(() => ({
    chip: document.getElementById('rowchip').textContent,
    n: applyFilters(S.rows).length,
    hash: location.hash,
  }));
  if (!filtered.hash.includes('territory=' + encodeURIComponent(terr)))
    fails.push('filter not persisted to URL: ' + filtered.hash);
  await page.selectOption('#fTerritory', '');
  await page.waitForTimeout(300);

  await page.click('[data-toggle="p3"]');
  await page.waitForTimeout(200);
  const tableShown = await page.evaluate(() => !!document.querySelector('#p3body table'));
  if (!tableShown) fails.push('p3 table view did not render');
  await page.click('[data-toggle="p3"]');
  await page.waitForTimeout(200);

  await page.click('#healthbtn');
  await page.waitForTimeout(300);
  const dlgOpen = await page.evaluate(() => document.getElementById('hdlg').open);
  if (!dlgOpen) fails.push('health dialog did not open');
  await page.screenshot({ path: './shot-health.png' });
  await page.evaluate(() => document.getElementById('hdlg').close());
  await page.waitForTimeout(200);

  // Overflow / clipping check on every panel
  const overflow = await page.evaluate(() => {
    const bad = [];
    document.querySelectorAll('.panel').forEach(p => {
      if (p.scrollWidth > p.clientWidth + 2) bad.push(p.id + ' overflows horizontally');
    });
    document.querySelectorAll('svg text').forEach(t => {
      const bb = t.getBoundingClientRect();
      if (bb.right > window.innerWidth || bb.left < 0) bad.push('svg label off-canvas: ' + t.textContent);
    });
    return bad;
  });
  fails.push(...overflow);

  await page.screenshot({ path: './shot-light-full.png', fullPage: true });
  await page.evaluate(() => document.documentElement.setAttribute('data-theme', 'dark'));
  await page.waitForTimeout(300);
  await page.screenshot({ path: './shot-dark-full.png', fullPage: true });
  await page.evaluate(() => document.documentElement.setAttribute('data-theme', 'light'));
  await page.waitForTimeout(250);
  await page.screenshot({ path: './shot-top.png', clip: { x: 0, y: 0, width: 1440, height: 1100 } });

  if (errors.length) fails.push(...errors);

  console.log('--- dashboard vs pandas ---');
  console.log('hero:', got.heroText, '| rows:', got.rows, '| asOf:', got.asOf);
  if (fails.length) { console.log('\nFAILURES (' + fails.length + '):'); fails.forEach(f => console.log('  ✗ ' + f)); }
  else console.log('\nALL CHECKS PASS — every dashboard number matches the independent pandas calculation.');

  await browser.close();
  process.exit(fails.length ? 1 : 0);
})();
