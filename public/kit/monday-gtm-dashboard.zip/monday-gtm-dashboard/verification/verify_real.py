"""Independent ground truth from pandas, compared against what the dashboard
computes in the browser. Anything that disagrees is a bug in the dashboard."""
import json, subprocess, sys
import pandas as pd
import numpy as np

CSV = "../deals-10k.csv"
TODAY = pd.Timestamp("2026-08-04")

df = pd.read_csv(CSV)
for c in ["Transaction_Date", "Expected_Close_Date", "Last_Activity_Date"]:
    df[c] = pd.to_datetime(df[c], errors="coerce")

won = df.Deal_Stage == "Closed Won"
lost = df.Deal_Stage == "Closed Lost"
openm = ~(won | lost)

truth = {}
truth["rows"] = int(len(df))
truth["won"] = int(won.sum())
truth["lost"] = int(lost.sum())
truth["open"] = int(openm.sum())
truth["winRate"] = round(float(won.sum() / (won.sum() + lost.sum())), 8)
truth["revenue"] = round(float(df.loc[won, "Final_Amount"].sum()), 2)
truth["discountGiven"] = round(float(df.loc[won, "Discount_Amount"].sum()), 2)
truth["realization"] = round(
    float(df.loc[won, "Final_Amount"].sum() / df.loc[won, "Total_Amount"].sum()), 8)
truth["cycleMedian"] = float(df.loc[won | lost, "Sales_Cycle_Days"].median())

# Panel 1: open deals expected to close within 30 days
w = openm & df.Expected_Close_Date.between(TODAY, TODAY + pd.Timedelta(days=30))
truth["p1_count"] = int(w.sum())
truth["p1_amount"] = round(float(df.loc[w, "Final_Amount"].sum()), 2)

# Panel 2: open deals untouched 30/60/90+ days
age = (TODAY - df.Last_Activity_Date).dt.days
for n in (30, 60, 90):
    m = openm & (age >= n)
    truth[f"p2_{n}_count"] = int(m.sum())
    truth[f"p2_{n}_amount"] = round(float(df.loc[m, "Final_Amount"].sum()), 2)

# Panel 3: win rate by discount band
bands = {}
for b, g in df[won | lost].groupby("Discount_Percent"):
    gw = int((g.Deal_Stage == "Closed Won").sum())
    gl = int((g.Deal_Stage == "Closed Lost").sum())
    bands[str(int(b))] = {"won": gw, "lost": gl, "n": gw + gl,
                          "rate": round(gw / (gw + gl), 8)}
truth["p3_bands"] = bands

# Panel 4: win rate vs named competitors
STATUSQUO = ["No competitor", "No-decision", "Internal build"]
named = (won | lost) & df.Competitor.notna() & ~df.Competitor.isin(STATUSQUO) & (df.Competitor != "")
nw = int((named & won).sum()); nl = int((named & lost).sum())
truth["p4_namedWinRate"] = round(nw / (nw + nl), 8)
truth["p4_namedN"] = nw + nl
sq_lost = lost & (df.Competitor.isna() | df.Competitor.isin(STATUSQUO) | (df.Competitor == ""))
truth["p4_sqLostShare"] = round(float(sq_lost.sum() / lost.sum()), 8)

# Panel 5: rep-said vs buyer-said mismatch
pool = lost & (df.Has_Buyer_Interview == "Yes") & df.Loss_Reason_Main.notna() & df.Buyer_Reported_Reason_Main.notna()
mis = pool & (df.Loss_Reason_Main != df.Buyer_Reported_Reason_Main)
truth["p5_pool"] = int(pool.sum())
truth["p5_mismatch"] = int(mis.sum())
truth["p5_mismatchRate"] = round(float(mis.sum() / pool.sum()), 8)
truth["p5_mismatchDollars"] = round(float(df.loc[mis, "Final_Amount"].sum()), 2)
truth["p5_interviewedLosses"] = int((lost & (df.Has_Buyer_Interview == "Yes")).sum())

# Health checks
truth["h_nullExpClose"] = int(df.Expected_Close_Date.isna().sum())
truth["h_nullLastAct"] = int(df.Last_Activity_Date.isna().sum())
truth["h_buyerEqSeller"] = int((df.Buyer_Company.str.lower().str.replace(r"[^a-z0-9]", "", regex=True)
                                == df.Seller_Company.str.lower().str.replace(r"[^a-z0-9]", "", regex=True)).sum())
seg = df.Customer_Segment.str.lower()
RANK = {"1-50":1,"51-200":2,"201-1000":3,"1001-5000":4,"5000":5}
rank = df.Company_Size.astype(str).str.strip().map(RANK)
truth["h_segConflict"] = int((((seg.str.contains("smb|small")) & (rank >= 4)) |
                              ((seg.str.contains("enterprise")) & (rank <= 1))).sum())
truth["h_probIsLookup"] = bool(df.groupby("Deal_Stage").Win_Probability.nunique().max() == 1)

with open("truth.json", "w") as f:
    json.dump(truth, f, indent=1)
print(json.dumps(truth, indent=1)[:1200])
