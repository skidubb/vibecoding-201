"""Synthetic deals CSV that mirrors the schema and the quirks the build plan
describes, so the dashboard can be verified without the real file."""
import csv, random, datetime as dt

random.seed(20260804)
N = 10000
TODAY = dt.date(2026, 8, 4)

STAGES = {
    "Prospecting": 10, "Qualification": 25, "Proposal": 50,
    "Negotiation": 75, "Closed Won": 100, "Closed Lost": 0,
}
STAGE_W = [0.16, 0.14, 0.10, 0.08, 0.28, 0.24]
TERRITORIES = ["AMER East", "AMER West", "EMEA", "APAC", "LATAM"]
SEGMENTS = ["SMB", "Mid-Market", "Enterprise"]
TIERS = ["Tier 1", "Tier 2", "Tier 3"]
PRODUCTS = ["Platform", "Analytics", "Security", "Integrations", "Support"]
COMPETITORS = ["Northwind", "Vertex Systems", "Apex Cloud", "Helio", "Meridian",
               "No competitor", "No-decision", "Internal build"]
COMP_W = [0.14, 0.12, 0.11, 0.08, 0.07, 0.18, 0.20, 0.10]
TAGS = ["no-decision", "champion churn", "incumbent switching cost", "consolidation",
        "regulatory block", "internal build", "stalled or deprioritized", ""]
LOSS_MAIN = ["Price / Value Position", "Product Performance", "Sales Experience",
             "Timing / Priority", "Relationship"]
LOSS_SUB = {
    "Price / Value Position": ["budget cut", "discount not approved", "ROI unclear"],
    "Product Performance": ["integrations", "missing feature", "performance"],
    "Sales Experience": ["discovery quality", "slow response", "too many handoffs"],
    "Timing / Priority": ["deprioritized", "reorg", "freeze"],
    "Relationship": ["champion left", "no exec sponsor", "procurement blocked"],
}
WIN_REASONS = ["Product fit", "Price", "Relationship", "Implementation speed"]
SIZES = {"SMB": (10, 200), "Mid-Market": (200, 2000), "Enterprise": (2000, 60000)}
REPS = [f"REP-{i:03d}" for i in range(1, 51)]
BUYERS = [f"{a} {b}" for a in
          ["Acme", "Blue Ridge", "Cobalt", "Dover", "Eastline", "Fairmont", "Granite",
           "Harbor", "Ironwood", "Juniper", "Keystone", "Lakeside", "Midway", "Northgate",
           "Oakfield", "Pinnacle", "Quarry", "Redstone", "Summit", "Trailhead", "Union",
           "Vantage", "Westport", "Yardley", "Zenith"]
          for b in ["Holdings", "Industries", "Group", "Partners", "Systems", "Labs",
                    "Logistics", "Health", "Financial", "Foods"]]
SELLER = "Pavilion Software"

HEADER = ["Deal_ID", "Buyer_Company", "Seller_Company", "Sales_Rep_ID", "Sales_Rep_Tier",
          "Territory", "Customer_Segment", "Company_Size", "Product_Category", "Deal_Stage",
          "Win_Probability", "Total_Amount", "Discount_Percent", "Discount_Amount",
          "Final_Amount", "Deal_Size_Category", "Transaction_Date", "Expected_Close_Date",
          "Last_Activity_Date", "Sales_Cycle_Days", "Contact_Count", "Competitor",
          "Win_Reason", "Loss_Reason_Main", "Loss_Reason_Sub",
          "Buyer_Reported_Reason_Main", "Buyer_Reported_Reason_Sub",
          "Has_Buyer_Interview", "Special_Tag", "Quarter", "Year", "Month",
          "Lead_Source", "Payment_Terms", "Renewal_Flag", "Notes"]


def d(x):
    return x.strftime("%Y-%m-%d")


rows = []
for i in range(N):
    stage = random.choices(list(STAGES), weights=STAGE_W)[0]
    closed = stage.startswith("Closed")
    won = stage == "Closed Won"
    seg = random.choices(SEGMENTS, weights=[0.42, 0.36, 0.22])[0]
    lo, hi = SIZES[seg]
    size = random.randint(lo, hi)
    # deliberate segment/size conflicts, as the plan flags
    if random.random() < 0.012:
        size = random.randint(3000, 8000) if seg == "SMB" else random.randint(20, 90)

    base = {"SMB": (4000, 40000), "Mid-Market": (25000, 180000),
            "Enterprise": (90000, 900000)}[seg]
    total = round(random.uniform(*base), 2)
    disc_pct = random.choices([0, 5, 10, 15, 20], weights=[0.30, 0.26, 0.22, 0.14, 0.08])[0]
    disc_amt = round(total * disc_pct / 100, 2)
    final = round(total - disc_amt, 2)

    create = TODAY - dt.timedelta(days=random.randint(240, 1100))
    if closed:
        cycle = random.randint(14, 240)
        txn = create + dt.timedelta(days=cycle)
        if txn > dt.date(2025, 12, 31):
            txn = dt.date(2025, 12, 31) - dt.timedelta(days=random.randint(0, 400))
            cycle = max(14, (txn - create).days)
        exp = txn - dt.timedelta(days=random.randint(-25, 40))
        last = txn + dt.timedelta(days=random.randint(0, 6))
    else:
        cycle = ""
        txn = create
        exp = TODAY + dt.timedelta(days=random.randint(-40, 500))
        last = TODAY - dt.timedelta(days=random.choices(
            [random.randint(0, 20), random.randint(21, 45), random.randint(46, 120)],
            weights=[0.72, 0.20, 0.08])[0])

    comp = random.choices(COMPETITORS, weights=COMP_W)[0] if closed else ""
    win_reason = random.choice(WIN_REASONS) if won else ""
    if closed and not won:
        # reps over-log price; buyers name other things
        rep_reason = random.choices(LOSS_MAIN, weights=[0.46, 0.16, 0.14, 0.16, 0.08])[0]
        interview = random.random() < 0.38
        if interview:
            buyer_reason = (rep_reason if random.random() < 0.42
                            else random.choices(LOSS_MAIN, weights=[0.14, 0.30, 0.26, 0.18, 0.12])[0])
            buyer_sub = random.choice(LOSS_SUB[buyer_reason])
        else:
            buyer_reason, buyer_sub = "", ""
        rep_sub = random.choice(LOSS_SUB[rep_reason])
    else:
        rep_reason = rep_sub = buyer_reason = buyer_sub = ""
        interview = False

    buyer = random.choice(BUYERS)
    if random.random() < 0.004:
        buyer = SELLER  # buyer == seller, as the plan flags

    exp_s, last_s = d(exp), d(last)
    if random.random() < 0.02:
        exp_s = ""
    if random.random() < 0.015:
        last_s = ""

    rows.append([
        f"D-{100000+i}", buyer, SELLER, random.choice(REPS), random.choice(TIERS),
        random.choice(TERRITORIES), seg, size, random.choice(PRODUCTS), stage,
        STAGES[stage], f"{total:.2f}", disc_pct, f"{disc_amt:.2f}", f"{final:.2f}",
        "Large" if total > 250000 else "Medium" if total > 50000 else "Small",
        d(txn), exp_s, last_s, cycle, random.randint(1, 9),
        comp, win_reason, rep_reason, rep_sub, buyer_reason, buyer_sub,
        "Yes" if interview else ("No" if closed and not won else ""),
        random.choice(TAGS) if closed and not won else "",
        f"Q{(txn.month-1)//3+1}", txn.year, txn.month,
        random.choice(["Inbound", "Outbound", "Partner", "Event"]),
        random.choice(["Net 30", "Net 45", "Net 60"]),
        random.choice(["Yes", "No"]), "",
    ])

with open("/home/claude/gtm/synth-deals.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(HEADER)
    w.writerows(rows)
print("wrote", len(rows), "rows,", len(HEADER), "columns")
