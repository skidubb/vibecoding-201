# Monday GTM Dashboard

One screen for a GTM leader opening it before a 9am pipeline call. Five panels,
one filter bar, and a data-health strip that never leaves the screen.

Built from `deals-10k.csv`: 10,000 rows, 36 columns, extract dated August 4, 2026.

## Which file to open

**`monday-gtm-dashboard-standalone.html`** is the one to hand out. The extract is
baked into the file, so it opens by double-click with no server, no internet, and
no setup. Verified running with all network traffic blocked. This is the version
for a class.

**`monday-gtm-dashboard.html`** is the same app pointed at the live CSV. It fetches
`https://storage.googleapis.com/vibecoding-201-data/deals-10k.csv` on load. If the
bucket refuses the cross-origin request, the page shows a file picker instead of an
error, and you point it at the CSV in this folder. Use `?csv=<url>` to aim it at a
different extract.

## Sharing it with a class

Ranked by how little can go wrong:

1. **Screen share.** Open the standalone file, share the browser tab. Filters live
   in the URL, so you can copy a link mid-session and paste it in chat for anyone
   following along on their own copy.
2. **Send the zip.** Everyone unzips and double-clicks the standalone file. Works
   offline, works on any OS, needs no install. One caveat worth saying out loud:
   the file is 2.7 MB because the data rides inside it.
3. **Host it.** Drop the standalone file on Vercel, Netlify, or GitHub Pages and
   share one URL. No build step, no config. It is a single static file.

## What each panel answers

| Panel | Question | Acts on |
| --- | --- | --- |
| Closing this month | What lands inside the horizon, and what already slipped | Open deals by expected close |
| Went quiet | Where is the money sitting untouched | Open deals by days since last activity |
| Discount leakage | Does deeper discounting buy anything | Closed deals by discount band |
| Where we lose, and to whom | Competitive loss or status quo | Closed deals by competitor |
| Rep said vs buyer said | Are we solving the problem the buyer named | Closed-lost with a buyer interview |

## Metric definitions

These live in one module (`const M`) inside the HTML. Change them there, never at
a call site.

- **Win rate** = Won / (Won + Lost). Open deals enter neither side.
- **Revenue** = `SUM(Final_Amount)` on won rows. `Total_Amount` is pre-discount and
  is never reported as revenue.
- **Realization** = `SUM(Final_Amount) / SUM(Total_Amount)` on won rows.
- **Days untouched** = today minus `Last_Activity_Date`, open rows only.
- **Cycle length** = median `Sales_Cycle_Days` on closed rows, median because the
  range runs wide.

Every aggregate prints its row count beside it. A win rate built on 9 deals reads
differently than one built on 900.

## What the data actually says

Every check below ran against all 10,000 rows, not a sample.

**Win_Probability is a stage lookup.** Prospecting is always 10, Qualification 25,
Proposal 50, Negotiation 75, Closed Won 100, Closed Lost 0. Zero variance inside any
stage. Weighting pipeline by it restates the stage mix with a dollar sign attached,
so no panel uses it.

**Discounting buys nothing measurable.** Win rate by band: 50.8% at 0%, 49.7% at 5%,
53.1% at 10%, 47.9% at 15%, 50.4% at 20%. The deepest band converts no better than
no discount at all, and the 15% band converts worst. $16.4M was given away across
2,546 won deals to move a number that did not move.

**A third of interviewed losses are attributed to the wrong thing.** 1,492 closed-lost
deals carry a buyer interview. In 506 of them (33.9%, $61.1M) the rep's logged reason
and the buyer's own answer disagree. The largest single pair: the rep logged
Price / Value Position and the buyer named Sales Experience, 89 deals worth $10.6M.
Discount authority cannot reach a discovery problem.

**$134M of open pipeline has an expected close date already in the past.** 1,086 open
deals. Another 572 open deals carry no expected close date at all and are invisible to
any forward-looking window.

**Closed history stops December 31, 2025.** Open deals expect to close between
April 2026 and February 2027. Any panel written as "last 90 days" against closed
history returns empty, which is why the trend work waits for Phase 2.

**Company_Size is noise.** It arrives as a band (`1-50`, `1001-5000`, `5000`) and is
statistically independent of Customer_Segment: every segment shows the same size mix
within a couple of points of the file-wide distribution. 1,798 rows fail a strict
segment-versus-size rule. Nothing slices by it, and neither should anything downstream.

**114 rows list the same company as buyer and seller.** Flagged in the health strip
rather than left for someone to find mid-meeting.

## What is deliberately missing

Week-over-week deltas. They need a snapshot table, and a single point-in-time extract
cannot produce one. The panels say "no prior snapshot" instead of showing a number
nobody can defend. Phase 3 adds the weekly snapshot job that makes deltas real.

## Verification

`verification/` holds the harness that proves the numbers.

- `verify_real.py` computes ground truth from the real CSV in pandas.
- `browsercheck.js` loads the dashboard in headless Chromium, pulls its own computed
  values out of the metrics module, and compares every one against the pandas result.
- `gen_synth.py` and `verify.py` do the same against synthetic data, which is how the
  app was built before the real file was available.

```
python3 verification/verify_real.py
python3 -m http.server 8899 &
node verification/browsercheck.js
```

Current state: all checks pass. Win rate, revenue, realization, all five discount
bands, competitor splits, the mismatch rate, and every health count match the
independent calculation.

## Still needed from the leader

- Quarterly target by territory, for coverage and attainment
- The dollar floor for the went-quiet list
- The fiscal calendar, if it differs from the calendar quarters in the file
- Whether the Monday view defaults to the whole book or one territory
